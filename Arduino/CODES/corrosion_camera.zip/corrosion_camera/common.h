//including library
#include <DHT.h>
#include <LiquidCrystal_I2C.h>
#include <OneWire.h>
#include <DallasTemperature.h>
#include <SPI.h>
#include <Ethernet.h>

byte mac[] = { 0xBE, 0xEF, 0xDE, 0xAD, 0xC0, 0xDE };
IPAddress ip(192, 168, 14, 40);

EthernetServer server(1880);        //port 1880
EthernetClient client;
unsigned long ultimoEnvio = 0;

// ds18b20 temp sensor
#define ONE_WIRE_BUS 4
OneWire oneWire(ONE_WIRE_BUS);
DallasTemperature sensors(&oneWire);

//define pin numbers
#define buzzer 10
#define red_led 8
#define green_led 9
#define fan_pin 6
#define potentiometer A0
#define DHTPIN 2

//define mq137
#define MQ137_PIN A2
const float MQ137_Ro = 10.5;
#define MQ137_RL 5.0

//define mq136
#define MQ136_PIN A1
const float MQ136_Ro = 68.5;
#define MQ136_RL 10.0

//define kind of sensor
#define DHTTYPE DHT11

//initial... sensor type dht11
DHT dht(DHTPIN, DHTTYPE);

//initial... lcd 
LiquidCrystal_I2C lcd(0x27, 20, 4);